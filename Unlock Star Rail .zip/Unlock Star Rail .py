import json
import os
import subprocess
import tkinter as tk
from tkinter import ttk, messagebox
from tkinter import font as tkfont

"""
Unlock Star Rail (HUD Version V12 )
--------------------------------------------------------
Features:
- Compact performance-focused HUD
- Smaller buttons for full visibility
- Blütenkirsche neon theme
- GPU auto detection (Windows only)
- Multiple performance presets (all with 120 FPS)
- FPS boosting options
- Self-contained, no external installs required
"""

LOCAL_CONFIG = os.path.join(os.path.expanduser('~'), 'unlock_star_rail_config.json')
HSR_CONFIG_PATH = os.path.join(os.path.expanduser('~'), 'AppData', 'LocalLow', 'Cognosphere', 'Star Rail', 'GraphicsSettings.json')

DEFAULT_CONFIG = {
    "fps": 120,
    "render_quality": 0.8,
    "shadows": False,
    "reflections": False,
    "bloom": False,
    "anti_aliasing": False,
    "unlock120": True,
    "neon_theme": "blutenkirsche",
    "boost_fps": True
}

PRESETS = {
    "POTATO": {"fps": 120, "render_quality": 0.6, "shadows": False, "reflections": False, "bloom": False, "anti_aliasing": False, "unlock120": True, "boost_fps": True},
    "PERFORMANCE": {"fps": 120, "render_quality": 0.8, "shadows": False, "reflections": False, "bloom": False, "anti_aliasing": False, "unlock120": True, "boost_fps": True},
    "BALANCED": {"fps": 120, "render_quality": 1.0, "shadows": False, "reflections": False, "bloom": True, "anti_aliasing": True, "unlock120": True, "boost_fps": True},
    "QUALITY": {"fps": 120, "render_quality": 1.0, "shadows": True, "reflections": True, "bloom": True, "anti_aliasing": True, "unlock120": True, "boost_fps": True},
    "ULTRA": {"fps": 120, "render_quality": 1.0, "shadows": True, "reflections": True, "bloom": True, "anti_aliasing": True, "unlock120": True, "boost_fps": True}
}

# ---------------- CONFIG FUNCTIONS ----------------

def load_config():
    try:
        if os.path.exists(LOCAL_CONFIG):
            with open(LOCAL_CONFIG, 'r') as f:
                return json.load(f)
    except Exception as e:
        print('Load config failed:', e)
    return DEFAULT_CONFIG.copy()

def save_local(cfg):
    try:
        with open(LOCAL_CONFIG, 'w') as f:
            json.dump(cfg, f, indent=4)
    except Exception as e:
        print('Save config failed:', e)

def apply_to_hsr(cfg):
    try:
        data = {}
        if os.path.exists(HSR_CONFIG_PATH):
            with open(HSR_CONFIG_PATH, 'r') as f:
                data = json.load(f)
        fps_value = min(cfg['fps'], 120)
        data.update({
            'FPS': fps_value,
            'RenderScale': cfg['render_quality'],
            'Shadows': int(cfg['shadows']),
            'Reflections': int(cfg['reflections']),
            'Bloom': int(cfg['bloom']),
            'AntiAliasing': int(cfg['anti_aliasing']),
            'BoostFPS': int(cfg['boost_fps'])
        })
        os.makedirs(os.path.dirname(HSR_CONFIG_PATH), exist_ok=True)
        with open(HSR_CONFIG_PATH, 'w') as f:
            json.dump(data, f, indent=4)
    except Exception as e:
        print('Apply to game failed:', e)

# ---------------- GPU DETECTION ----------------

def detect_gpu():
    try:
        output = subprocess.check_output('wmic path win32_VideoController get name', shell=True, stderr=subprocess.DEVNULL).decode()
        lines = [l.strip() for l in output.split('\n') if l.strip() and 'Name' not in l]
        return lines[0] if lines else 'Unknown GPU'
    except:
        return 'Unknown GPU'

# ---------------- UI ----------------
class App:
    def __init__(self, root):
        self.root = root
        self.root.title('Unlock Star Rail (HUD V12)')
        self.root.geometry('700x600')
        self.root.resizable(False, False)
        self.canvas = tk.Canvas(root, highlightthickness=0)
        self.canvas.pack(fill='both', expand=True)
        self.cfg = load_config()
        self.neon_theme = self.cfg.get('neon_theme', 'blutenkirsche')
        self.draw_gradient()
        self.container = tk.Frame(self.canvas, bg='#1a0d1f')
        self.container.place(relx=0.5, rely=0.5, anchor='center')
        self.setup_ui()

    def setup_ui(self):
        self.title_font = tkfont.Font(size=24, weight='bold')
        self.label_font = tkfont.Font(size=14)
        self.button_font = tkfont.Font(size=10, weight='bold')
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('TLabel', background='#1a0d1f', foreground='#ff77c9', font=self.label_font)
        style.configure('TButton', font=self.button_font, padding=4)
        title = tk.Label(self.container, text='UNLOCK STAR RAIL V12', bg='#1a0d1f', fg='#ff77c9', font=self.title_font)
        title.pack(pady=8)
        self.gpu_name = detect_gpu()
        gpu_label = tk.Label(self.container, text=f'Detected GPU: {self.gpu_name}', bg='#1a0d1f', fg='#ff77c9', font=self.label_font)
        gpu_label.pack(pady=4)
        self.create_options()

    def create_options(self):
        grid = tk.Frame(self.container, bg='#1a0d1f')
        grid.pack(pady=5)
        ttk.Label(grid, text='FPS Limit').grid(row=0, column=0, sticky='w', pady=4)
        self.fps = tk.IntVar(value=self.cfg['fps'])
        ttk.Combobox(grid, textvariable=self.fps, values=[30, 60, 120], width=10).grid(row=0, column=1)
        ttk.Label(grid, text='Render Quality').grid(row=1, column=0, sticky='w', pady=4)
        self.render = tk.DoubleVar(value=self.cfg['render_quality'])
        ttk.Combobox(grid, textvariable=self.render, values=[0.6, 0.8, 1.0], width=10).grid(row=1, column=1)
        self.shadows = tk.BooleanVar(value=self.cfg['shadows'])
        self.reflections = tk.BooleanVar(value=self.cfg['reflections'])
        self.bloom = tk.BooleanVar(value=self.cfg['bloom'])
        self.aa = tk.BooleanVar(value=self.cfg['anti_aliasing'])
        self.unlock120 = tk.BooleanVar(value=True)
        self.boost_fps = tk.BooleanVar(value=self.cfg.get('boost_fps', True))
        for idx, (text, var) in enumerate([
            ('Enable Shadows', self.shadows),
            ('Enable Reflections', self.reflections),
            ('Bloom', self.bloom),
            ('Anti Aliasing', self.aa),
            ('Unlock 120 FPS', self.unlock120),
            ('Boost FPS Options', self.boost_fps)
        ]):
            tk.Checkbutton(grid, text=text, variable=var, bg='#1a0d1f', fg='#ff77c9', font=self.label_font, selectcolor='#222', activebackground='#1a0d1f').grid(row=idx+2, column=0, columnspan=2, sticky='w', pady=3)
        self.create_buttons()

    def create_buttons(self):
        btn_frame = tk.Frame(self.container, bg='#1a0d1f')
        btn_frame.pack(pady=10)
        for idx, preset in enumerate(['POTATO', 'PERFORMANCE', 'BALANCED', 'QUALITY', 'ULTRA']):
            ttk.Button(btn_frame, text=preset, command=lambda p=preset: self.apply_preset(p)).grid(row=0, column=idx, padx=4, pady=2)
        action_frame = tk.Frame(self.container, bg='#1a0d1f')
        action_frame.pack(pady=10)
        ttk.Button(action_frame, text='AUTO OPTIMIZE', command=self.auto_optimize).grid(row=0, column=0, padx=6)
        ttk.Button(action_frame, text='APPLY TO GAME', command=self.apply).grid(row=0, column=1, padx=6)
        ttk.Button(action_frame, text='SAVE PROFILE', command=self.save).grid(row=0, column=2, padx=6)

    def draw_gradient(self):
        width, height = 700, 600
        start_color = (255, 119, 201)
        end_color = (20, 0, 40)
        for i in range(height):
            r = int(start_color[0] + (end_color[0]-start_color[0])*i/height)
            g = int(start_color[1] + (end_color[1]-start_color[1])*i/height)
            b = int(start_color[2] + (end_color[2]-start_color[2])*i/height)
            self.canvas.create_line(0, i, width, i, fill=f'#{r:02x}{g:02x}{b:02x}')

    def apply_preset(self, name):
        p = PRESETS.get(name, DEFAULT_CONFIG)
        self.fps.set(p['fps'])
        self.render.set(p['render_quality'])
        self.shadows.set(p['shadows'])
        self.reflections.set(p['reflections'])
        self.bloom.set(p['bloom'])
        self.aa.set(p['anti_aliasing'])
        self.unlock120.set(p['unlock120'])
        self.boost_fps.set(p['boost_fps'])

    def auto_optimize(self):
        gpu = detect_gpu().lower()
        preset = 'ULTRA' if any(x in gpu for x in ['rtx','rx 7','rx 6']) else 'BALANCED' if any(x in gpu for x in ['gtx','rx 5']) else 'PERFORMANCE'
        self.apply_preset(preset)
        messagebox.showinfo('Auto Optimize', f'Preset applied: {preset}')

    def save(self):
        save_local(self.collect())
        messagebox.showinfo('Saved', 'Profile saved.')

    def apply(self):
        apply_to_hsr(self.collect())
        messagebox.showinfo('Applied', 'Tweaks written to Star Rail config.')

    def collect(self):
        return {
            'fps': self.fps.get(),
            'render_quality': self.render.get(),
            'shadows': self.shadows.get(),
            'reflections': self.reflections.get(),
            'bloom': self.bloom.get(),
            'anti_aliasing': self.aa.get(),
            'unlock120': True,
            'boost_fps': self.boost_fps.get(),
            'neon_theme': self.neon_theme
        }

if __name__ == '__main__':
    root = tk.Tk()
    app = App(root)
    root.mainloop()
